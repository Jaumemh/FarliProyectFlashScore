using System;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace FlashscoreOverlay
{
    public partial class MainWindow : Window
    {
        private Server _server;
        private ConcurrentDictionary<string, OverlayWindow> _activeOverlays = new ConcurrentDictionary<string, OverlayWindow>();

        public MainWindow()
        {
            InitializeComponent();
            _server = new Server();
            _server.OnRequestReceived += Server_OnRequestReceived;
            _server.Start();
        }

        private void Server_OnRequestReceived(RequestData request)
        {
            Dispatcher.Invoke(() =>
            {
                LogListBox.Items.Insert(0, $"Received: {request.action} at {DateTime.Now}");

                if (request.action == "ping")
                {
                    // Just a ping
                }
                else if (request.action == "addMatch")
                {
                    HandleAddMatch(request.data);
                }
                else if (request.action == "removeMatch")
                {
                    HandleRemoveMatch(request.data);
                }
            });
        }

        private void HandleAddMatch(MatchPayload payload)
        {
            if (payload?.match == null) return;
            string matchId = payload.match.matchId;

            if (_activeOverlays.ContainsKey(matchId))
            {
                // Already open, bring to front or update?
                var window = _activeOverlays[matchId];
                if (window.WindowState == WindowState.Minimized)
                    window.WindowState = WindowState.Normal;
                window.Activate();
                return;
            }

            var overlay = new OverlayWindow(payload.match);
            overlay.Closed += (s, e) => _activeOverlays.TryRemove(matchId, out _);
            _activeOverlays.TryAdd(matchId, overlay);
            overlay.Show();
        }

        private void HandleRemoveMatch(MatchPayload payload)
        {
             if (payload?.match == null) return;
             string matchId = payload.match.matchId;

             if (_activeOverlays.TryRemove(matchId, out var window))
             {
                 window.Close();
             }
        }

        protected override void OnClosed(EventArgs e)
        {
            _server.Stop();
            foreach(var window in _activeOverlays.Values)
            {
                window.Close();
            }
            base.OnClosed(e);
        }
    }
}
