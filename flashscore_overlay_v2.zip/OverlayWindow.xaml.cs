using System;
using System.Windows;
using System.Windows.Input;
using Microsoft.Web.WebView2.Core;
using Newtonsoft.Json;
using System.Diagnostics;

namespace FlashscoreOverlay
{
    public partial class OverlayWindow : Window
    {
        private MatchDetails _match;
        private bool _isLoaded;

        public OverlayWindow(MatchDetails match)
        {
            InitializeComponent();
            _match = match;
            Loaded += OverlayWindow_Loaded;
        }

        private async void OverlayWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (_isLoaded) return;
            _isLoaded = true;

            try
            {
                // Ensure environment is initialized
                var env = await CoreWebView2Environment.CreateAsync();
                await webView.EnsureCoreWebView2Async(env);

                // Handle messages (e.g., resize requests from JS)
                webView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
                
                // Hide default context menu
                webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

                // Handle external links
                webView.NavigationStarting += WebView_NavigationStarting;
                webView.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;

                // Navigate to the match URL
                if (!string.IsNullOrEmpty(_match.url))
                {
                    webView.Source = new Uri(_match.url);
                }
                else
                {
                    // Fallback to HTML string if no URL (static view)
                    webView.NavigateToString(_match.html);
                }

                webView.NavigationCompleted += WebView_NavigationCompleted;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing WebView2: {ex.Message}");
            }
        }

        private async void WebView_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (!e.IsSuccess) return;

            // Inject CSS to hide everything except the match header
            // Try to find the match detail header. On Flashscore desktop it's often .duelParticipant
            // We also hide adds, footer, header menu, etc.
            string css = @"
                body { overflow: hidden; background: #121212 !important; }
                /* Hide everything by default */
                body > * { display: none !important; }
                
                /* Show only the target container */
                .duelParticipant, .teamHeader__container, .tournamentHeader { 
                    display: block !important; 
                    position: fixed; 
                    top: 0; 
                    left: 0; 
                    width: 100%; 
                    z-index: 9999;
                    background: #121212;
                }
                /* Hide ads inside */
                .ads, .box-over-content, header, footer { display: none !important; }
            ";

            await webView.CoreWebView2.ExecuteScriptAsync($@"
                var style = document.createElement('style');
                style.innerHTML = `{css}`;
                document.head.appendChild(style);
                
                // Resize window based on content size
                function reportSize() {{
                     const target = document.querySelector('.duelParticipant') || 
                                    document.querySelector('.teamHeader__container') || 
                                    document.querySelector('.tournamentHeader');
                     if(target) {{
                         const rect = target.getBoundingClientRect();
                         window.chrome.webview.postMessage(JSON.stringify({{ 
                             type: 'resize', 
                             width: rect.width, 
                             height: rect.height 
                         }}));
                     }}
                }}
                
                // Report size initially and on resize
                setTimeout(reportSize, 500);
                setTimeout(reportSize, 2000);
                window.addEventListener('resize', reportSize);
                
                // Auto-refresh logic (if needed, Flashscore usually has live updates via socket)
                // If socket fails, reload every 30s
                // setInterval(() => location.reload(), 30000); 
            ");
        }

        private void CoreWebView2_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                var json = e.TryGetWebMessageAsString();
                dynamic data = JsonConvert.DeserializeObject(json);

                if (data.type == "resize")
                {
                    double width = (double)data.width;
                    double height = (double)data.height;

                    // Add some padding for the border
                    this.Width = width + 2; 
                    this.Height = height + 2;
                }
            }
            catch { }
        }

        private void DragWindow(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void WebView_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            // Intercept team links (or any other desired external link)
            // Example link: https://www.flashscore.es/equipo/elche-cf/4jl02tPF/
            if (e.Uri != null && e.Uri.Contains("/equipo/"))
            {
                e.Cancel = true;
                OpenInBrowser(e.Uri);
            }
        }

        private void CoreWebView2_NewWindowRequested(object sender, CoreWebView2NewWindowRequestedEventArgs e)
        {
            // Handle links that try to open in a new window/tab
            e.Handled = true;
            if (e.Uri != null)
            {
                OpenInBrowser(e.Uri);
            }
        }

        private void OpenInBrowser(string url)
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                // Fallback for some systems or handle error
                MessageBox.Show($"Could not open link: {ex.Message}");
            }
        }
    }
}
