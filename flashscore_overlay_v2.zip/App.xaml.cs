using System.Windows;

namespace FlashscoreOverlay
{
    public partial class App : Application
    {
    }
}
