using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FlashscoreOverlay
{
    public class Server
    {
        private HttpListener _listener;
        private bool _isRunning;
        private const string Url = "http://localhost:8080/";

        public event Action<RequestData> OnRequestReceived;

        public async void Start()
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add(Url);
            _listener.Start();
            _isRunning = true;

            Console.WriteLine($"Server started on {Url}");

            while (_isRunning)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    ProcessRequest(context);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Server error: {ex.Message}");
                }
            }
        }

        private async void ProcessRequest(HttpListenerContext context)
        {
            try
            {
                if (context.Request.HttpMethod == "POST")
                {
                    // Handle CORS
                    context.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                    context.Response.Headers.Add("Access-Control-Allow-Methods", "POST, OPTIONS");
                    context.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");

                    using (var reader = new StreamReader(context.Request.InputStream, context.Request.ContentEncoding))
                    {
                        string json = await reader.ReadToEndAsync();
                        var data = JsonConvert.DeserializeObject<RequestData>(json);
                        
                        // Fire event on UI thread if needed, but here we just invoke the event
                        OnRequestReceived?.Invoke(data);
                    }

                    byte[] buffer = Encoding.UTF8.GetBytes("{\"status\":\"ok\"}");
                    context.Response.ContentLength64 = buffer.Length;
                    context.Response.ContentType = "application/json";
                    await context.Response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
                }
                else if (context.Request.HttpMethod == "OPTIONS")
                {
                   // Handle CORS preflight
                    context.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                    context.Response.Headers.Add("Access-Control-Allow-Methods", "POST, OPTIONS");
                    context.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");
                    context.Response.StatusCode = 200;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing request: {ex.Message}");
                context.Response.StatusCode = 500;
            }
            finally
            {
                context.Response.Close();
            }
        }

        public void Stop()
        {
            _isRunning = false;
            _listener.Stop();
        }
    }

    public class RequestData
    {
        public string action { get; set; }
        public MatchPayload data { get; set; }
    }

    public class MatchPayload
    {
        public MatchDetails match { get; set; }
        public CompetitionDetails competition { get; set; }
        public string message { get; set; } // For ping
    }

    public class MatchDetails
    {
        public string matchId { get; set; }
        public string homeTeam { get; set; }
        public string awayTeam { get; set; }
        public string homeScore { get; set; }
        public string awayScore { get; set; }
        public string time { get; set; }
        public string stage { get; set; }
        public string homeLogo { get; set; }
        public string awayLogo { get; set; }
        public string url { get; set; }
        public string html { get; set; }
    }

    public class CompetitionDetails
    {
        public string competitionId { get; set; }
        public string title { get; set; }
        public string category { get; set; }
        public string logo { get; set; }
    }
}
